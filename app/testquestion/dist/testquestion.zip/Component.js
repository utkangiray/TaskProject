sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("test.com.testquestion.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map