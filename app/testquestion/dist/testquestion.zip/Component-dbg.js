sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("test.com.testquestion.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);